/*
 * Vertex.cpp
 *
 *  Created on: Sep 24, 2018
 *      Author: Shanty1
 */

#include "Vertex.h"


Vertex::Vertex(float xCoord, float yCoord) {
	// TODO Auto-generated constructor stub
	x = xCoord;
	y = yCoord;
}

Vertex::~Vertex() {
	// TODO Auto-generated destructor stub
}

