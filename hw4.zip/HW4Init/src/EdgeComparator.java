import java.util.Comparator;

public class EdgeComparator implements Comparator<Edge> {

	@Override
	public int compare(Edge arg0, Edge arg1) {
		if (arg0.v1 == arg1.v1) {
			if (arg0.weight > arg1.weight)
				return -1;
			else if (arg1.weight < arg0.weight)
				return 1;
		}
		return 0;
		
	}

}
