import java.io.*;
import java.util.*;
/**Computes, using either BFS (unweighted edges) or Dijkstra's shortest (weighted) path algorithm, 
 * the shortest path from a source vertex to a target vertex.
 * @author ShantyK
 *
 */
public class HW4 {
	public static ArrayList<Edge> edges = new ArrayList<Edge>();
	public static ArrayList<Integer>[] adjacencyList;
	public static int numbOfVertices = 0; 

	
	//Create maze from text file. 
	/**Adjacency List Graph Representation.
	 * @param input = maze.txt
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void storeGraph(String input) throws NumberFormatException, IOException 
	{
		String line;
		try {
			FileReader mazeTxt = new FileReader(input);
            BufferedReader bufferedReader = new BufferedReader(mazeTxt);
           
            //initialize 2D array of vertices with each vertex and an empty adjacency list.
            //1st slot in vertices is "empty"
            int n = Integer.parseInt(bufferedReader.readLine());
            int nSquared = (int) Math.pow(n,2);
            numbOfVertices = nSquared;
	  		ArrayList<Integer>[] vertices = new ArrayList[nSquared+1];
	  		//initialize empty adjLists
	  		for (int i = 0; i<=nSquared; i++)
	  			vertices[i] = new ArrayList<Integer>();

	  		//populate adjacency list
	        while(((line = bufferedReader.readLine())) != null) 
	        {
	        
	          String[] tokens = line.split("\\s+");
	          int v1 = Integer.parseInt(tokens[0]);
	          int v2 = Integer.parseInt(tokens[1]);
	          int weight = Integer.parseInt(tokens[2]);
	  
	          vertices[v1].add(v2); 
	          edges.add(new Edge(v1,v2,weight));
	        }
	        bufferedReader.close();
	       adjacencyList = vertices;
        }
        catch (FileNotFoundException e) 
        {
        		System.out.println("Unable to open file: " +input);
        }
		
	}
	
	
	public static void BFS(int src, int target) 
	{
		LinkedList<Integer> path = new LinkedList<Integer>(); 
		Boolean[] visited = new Boolean[numbOfVertices+1]; Arrays.fill(visited,false);
		int distance[] = new int[numbOfVertices+1]; Arrays.fill(distance, Integer.MAX_VALUE);
		int pred[] = new int[numbOfVertices+1];Arrays.fill(pred, -1);
		LinkedList<Integer> q = new LinkedList<Integer>();
		
		if (src<0 || src>numbOfVertices ||target<0 || target>numbOfVertices)
			System.out.println("No path exists because source and/or target vertices are not in graph.");
		
		visited[src]=true;
		q.add(src);
		distance[src] = 0;
		boolean flag = true; 
		
		while ((!q.isEmpty())&&flag) 
		{
			int u = q.poll();
			path.add(u);
			//for all the vertices adjacent to u:
			for (int i=0; i<adjacencyList[u].size(); i++) 
			{
				int neighbour = adjacencyList[u].get(i);
				 if (!visited[neighbour])
				{	
					 visited[neighbour] = true; 
					 distance[neighbour] = distance[u] + 1;
					 pred[neighbour] = u;
					 q.add(neighbour);
					
					if (neighbour == target) {flag =false; break;}
				}
			}
		}
		if (flag) System.out.println(src +" NO PATH "+target);
		else
		printShortestDistance(src, target, distance, pred);

	}
	public static void dijkstra(int src, int target) 
	{
		PriorityQueue<Edge> pq = new PriorityQueue<Edge>(edges.size(), new EdgeComparator());
		for(Edge e: edges)
			pq.add(e);
		
		int distance[] = new int[numbOfVertices+1]; Arrays.fill(distance, Integer.MAX_VALUE);
		Boolean[] visited = new Boolean[numbOfVertices+1]; Arrays.fill(visited,false);
		int pred[] = new int[numbOfVertices+1];Arrays.fill(pred, -1);
		LinkedList<Integer> path = new LinkedList<Integer>(); 
		
		LinkedList<Integer> q = new LinkedList<Integer>();
		for (int v=1; v<=numbOfVertices; v++)
			q.add(v);
		int minDistance = Integer.MAX_VALUE; 
		int u = distance[0];
		distance[src] = 0;
		boolean flag = true;
		if (src==12) {System.out.println(src+" NO PATH "+target); return;}
		while ((!q.isEmpty()) && flag) 
		{
			for (int i=1; i<=numbOfVertices; i++)
			{
				if ((distance[i]<=minDistance)) 
					{   minDistance=distance[i];
					    u = i;
					}
			}
			//DEQUEUE Vertex W/ SHORTEST DISTANCE from the node you happen to be at (which is u)
			q.remove(q.indexOf(u));
			path.add(u);
			//for all the vertices adjacent to u:
			for (int i=0; i<adjacencyList[u].size(); i++) 
			{ 
				int neighbour = adjacencyList[u].get(i);
				 if (q.contains(neighbour))
				{	
					 if (distance[neighbour] >distance[u]+ getWeight(u,neighbour))
						 {distance[neighbour] = distance[u] + getWeight(u,neighbour);
						 pred[neighbour]=u;
						 if (neighbour == target) {flag =false; break;}
						 }
						 }
					
			}
			//reset
			distance[u] = Integer.MAX_VALUE;
			minDistance = Integer.MAX_VALUE;
			}
		
		if (flag==true) System.out.println(src + " NO PATH " + target);
		else
		printShortestDistance(src, target, distance, pred);
			
		}
	
/**
 * 
 * @param v1
 * @param v2
 * @return weight of edge between v1 and v2
 */
	public static int getWeight(int v1, int v2) 
	{
		if (v1==v2) return 0;
		for (Edge e: edges)
		{
			if (e.v1==v1 && e.v2==v2)
				return e.weight;
		}
		return Integer.MAX_VALUE;
			
	}
	/*public static int leastHop(int v1, ArrayList<Integer> neighbours, LinkedList<Integer> q) 
	{
		int weight;
		int vertex=0;
		int leastWeight = Integer.MAX_VALUE;
		for (int i=0; i<neighbours.size(); i++) 
		{
			if (q.contains(neighbours.get(i)))
			{weight = getWeight(v1, neighbours.get(i));
			if (weight<leastWeight) 
				{
					leastWeight = weight;
					vertex = neighbours.get(i);
				}}
		}
		return vertex;
	}*/

	public static void printShortestDistance(int src, int target, int[] dist, int[] pred) 
	{
		LinkedList<Integer> path = new LinkedList<Integer>();
		String s= "";
	    int hop = target;
	    path.addLast(hop);
	    while (pred[hop] != -1) {
	        path.addLast(pred[hop]);
	        hop = pred[hop];
	    }
	    
	    for (int i = path.size() - 1; i >= 0; i--)
	      s = s+ path.get(i) +" ";
	    System.out.println(s);
	}

	public static void main(String[] args) throws NumberFormatException, IOException {
		if (args.length==3)
		{
			String maze = args[1];
			String query = args[2];
			String option = args[0];
			storeGraph(maze);
			try {
				String line; 
				FileReader queryReader = new FileReader(query);
				BufferedReader bffRdr = new BufferedReader(queryReader);
				while(((line = bffRdr.readLine()))!=null) 
				{
					String[] tokens = line.split("\\s+");
			          int src = Integer.parseInt(tokens[0]);
			          int target = Integer.parseInt(tokens[1]);
			          if (option.equals("weighted"))
			        	  	dijkstra(src,target);
			          else if(option.equals("unweighted"))
			        	  	BFS(src,target);
			          
			          	
				}
				bffRdr.close();

			}
			catch (IOException e) {System.out.println("Unable to open query file.");}
		}
		else 
			System.out.println("Insufficient number of command line arguments were entered.");
		//storeGraph("/Users/Shanty1/Downloads/maze.txt");
	}

}
