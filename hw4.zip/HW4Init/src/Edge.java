
public class Edge {
	int v1, v2, weight;
	
	public Edge(int from, int to, int w) 
	{
		this.v1 = from; 
		this.v2 = to; 
		this.weight = w;
	}
	@Override
	public String toString() 
	{
		String s = v1 + " --" + weight + "-- " + v2;
		return s;
	}
	

}
